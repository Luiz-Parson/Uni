﻿using ConnectorAccess.Service.data;
using ConnectorAccess.Service.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.Data;

namespace ConnectorAccess.Service.config
{
    public static class DependencyInjectionConfig
    {
        public static IServiceCollection ConfigureServices()
        {
            var services = new ServiceCollection();

            // Configurar o EF Core
            services.AddDbContext<ConnectorDbContext>(options =>
                options.UseSqlServer("Data Source=localhost;Initial Catalog=ConnectorFasano;User Id=sa;Password=123456"));

            // Repositórios e Serviços
            services.AddScoped(typeof(IRepository<>), typeof(Repository<>));
            services.AddScoped<AccessControlService>();
            services.AddScoped<ProductService>();
            services.AddScoped<SystemUserService>();

            return services;
        }
    }
}
