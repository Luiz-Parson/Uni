﻿using ConnectorAccess.Service.data;
using ConnectorAccess.Service.models;
using ConnectorAccess.Service.models.dtos;
using System;
using System.Collections.Generic;
using System.Linq;

namespace ConnectorAccess.Service.Services
{
    public class ProductService
    {
        private readonly ConnectorDbContext context;

        public ProductService(ConnectorDbContext context)
        {
            this.context = context;
        }

        public Product GetProductByEpc(string epc)
        {
            return context.Product.FirstOrDefault(p => p.EPC == epc && p.DeletedOn == null);
        }

        public List<Product> GetAllProducts()
        {
            return context.Product.Where(p => p.DeletedOn == null).ToList();
        }

        public List<SKUAndDescriptionDTO> GetAllSKUsAndDescriptions()
        {
            return context.Product
                          .Where(p => p.DeletedOn == null)
                          .Select(p => new SKUAndDescriptionDTO
                          {
                              SKU = p.SKU,
                              Description = p.Description
                          })
                          .Distinct()
                          .ToList();
        }


        public Product AddProduct(string description, string sku, string epc, string createdBy)
        {
            var product = new Product
            {
                Description = description,
                SKU = sku,
                EPC = epc,
                CreatedBy = createdBy,
                CreatedOn = DateTime.Now,
                UpdatedBy = createdBy,
                UpdatedOn = DateTime.Now
            };

            context.Product.Add(product);
            context.SaveChanges();

            return product;
        }

        public Product UpdateProductById(int id, string description, string sku, string epc, string updatedBy)
        {
            var product = context.Product.FirstOrDefault(p => p.Id == id);

            if (product == null)
            {
                throw new Exception("Produto não encontrado!");
            }

            product.Description = description;
            product.SKU = sku;
            product.EPC = epc;
            product.UpdatedBy = updatedBy;
            product.UpdatedOn = DateTime.Now;

            context.SaveChanges();

            return product;
        }

        public Product DeleteProductById(int id, string deletedBy)
        {
            var product = context.Product.FirstOrDefault(p => p.Id == id && p.DeletedOn == null);

            if (product == null)
            {
                throw new Exception("Produto não encontrado ou já foi excluído!");
            }

            product.DeletedOn = DateTime.Now;
            product.DeletedBy = deletedBy;
            product.UpdatedBy = deletedBy;
            product.UpdatedOn = DateTime.Now;

            context.SaveChanges();

            return product;
        }
    }
}
