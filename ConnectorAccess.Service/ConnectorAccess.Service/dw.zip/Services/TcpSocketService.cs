﻿using System;
using System.Net.Sockets;
using System.Text;

namespace ConnectorAccess.Service.Services
{
    public class TcpSocketService
    {

        private readonly string serverIp;
        private readonly int serverPort;

        public TcpSocketService(string serverIp, int serverPort)
        {
            this.serverIp = serverIp;
            this.serverPort = serverPort;
        }

        public void Start()
        {
            try
            {
                using (TcpClient client = new TcpClient(serverIp, serverPort))
                {
                    Console.WriteLine("Conectado ao leitor RFID.");

                    // Obter o fluxo de dados
                    NetworkStream stream = client.GetStream();

                    // Buffer para armazenar dados recebidos
                    byte[] buffer = new byte[1024];

                    while (true)
                    {
                        // Lê os dados enviados pelo leitor
                        int bytesRead = stream.Read(buffer, 0, buffer.Length);
                        if (bytesRead > 0)
                        {
                            string message = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                            Console.WriteLine($"Mensagem recebida: {message}");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Erro: {ex.Message}");
            }
        }

    }
}
