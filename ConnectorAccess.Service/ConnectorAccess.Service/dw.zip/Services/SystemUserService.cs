﻿using ConnectorAccess.Service.data;
using ConnectorAccess.Service.models;
using System;

namespace ConnectorAccess.Service.Services
{
    public class SystemUserService
    {
        private readonly ConnectorDbContext context;

        public SystemUserService(ConnectorDbContext context)
        {
            this.context = context;
        }

        public void addSystemUser(string username, string password, bool isAdmin, string createdBy)
        {
            var systemUser = new SystemUser
            {
                Username = username,
                Password = password,
                IsAdmin = isAdmin,
                CreatedBy = createdBy,
                CreatedOn = DateTime.Now,
                UpdatedBy = createdBy,
                UpdatedOn = DateTime.Now
            };

            context.SystemUser.Add(systemUser);
            context.SaveChanges();
        }
    }
}
