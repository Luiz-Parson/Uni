﻿namespace ConnectorAccess.Service.models.dtos
{
    public class ProductUpdateDTO
    {
        public string Description { get; set; }
        public string SKU { get; set; }
        public string EPC { get; set; }
        public string UpdatedBy { get; set; }
    }
}
