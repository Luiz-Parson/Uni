﻿namespace ConnectorAccess.Service.models.dtos
{
    public class SKUAndDescriptionDTO
    {
        public string SKU { get; set; }
        public string Description { get; set; }
    }
}
