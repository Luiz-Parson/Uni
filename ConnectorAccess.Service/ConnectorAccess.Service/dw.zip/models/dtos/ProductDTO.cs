﻿namespace ConnectorAccess.Service.models.dtos
{
    public class ProductDTO
    {
        public string Description { get; set; }
        public string SKU { get; set; }
        public string EPC { get; set; }
        public string CreatedBy { get; set; }
    }
}
