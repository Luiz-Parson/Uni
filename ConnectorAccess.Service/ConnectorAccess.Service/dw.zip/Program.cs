using ConnectorAccess.Service.config;
using ConnectorAccess.Service.data;
using ConnectorAccess.Service.Services;
using Hangfire;
using Microsoft.AspNetCore.Builder;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Serilog;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ConnectorAccess.Service
{
    public class Program
    {
        private static string configFile = "appsettings.json";
        private static string basePath = "";

        public static void Main(string[] args)
        {
            // Definir o diret�rio base
            basePath = AppContext.BaseDirectory;

            // Configurar Serilog
            var configuration = new ConfigurationBuilder()
                .SetBasePath(basePath)
                .AddJsonFile(configFile, optional: false, reloadOnChange: true)
                .AddEnvironmentVariables()
                .Build();

            Log.Logger = new LoggerConfiguration()
                .ReadFrom.Configuration(configuration)
                .Enrich.FromLogContext()
                .CreateLogger();

            try
            {
                Log.Information("Iniciando a aplica��o...");

                var builder = WebApplication.CreateBuilder(args);

                // Adicionar Serilog ao pipeline
                builder.Host.UseSerilog();

                // Configurar para rodar como servi�o do Windows
                builder.Host.UseWindowsService();

                builder.Services.AddControllers();

                // Configurar o EF Core com a string de conex�o
                builder.Services.AddDbContext<ConnectorDbContext>(options =>
                    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

                // Configura��o do Hangfire com SQL Server
                builder.Services.AddHangfire(config => config
                    .SetDataCompatibilityLevel(CompatibilityLevel.Version_170)
                    .UseSimpleAssemblyNameTypeSerializer()
                    .UseRecommendedSerializerSettings()
                    .UseSqlServerStorage(builder.Configuration.GetConnectionString("DefaultConnection")));

                builder.Services.AddHangfireServer();

                // Configurar depend�ncias
                DependencyInjectionConfig.ConfigureServices();
                builder.Services.AddScoped<ProductService>();
                builder.Services.AddScoped<AccessControlService>();
                builder.Services.AddScoped<AccessControlDay>();
                builder.Services.Configure<EmailService>(builder.Configuration.GetSection("EmailSettings"));
                builder.Services.AddScoped<EmailService>();

                // Construir a aplica��o
                var app = builder.Build();

                // Configurar middlewares essenciais
                app.UseRouting();
                app.MapControllers();

                // Ativa o Dashboard do Hangfire (Opcional, pode acessar em /hangfire)
                app.UseHangfireDashboard();

                // Obt�m o servi�o de e-mail e agenda o job
                using (var scope = app.Services.CreateScope())
                {
                    var emailService = scope.ServiceProvider.GetRequiredService<EmailService>();

                    // Obt�m o hor�rio do appsettings.json via EmailService
                    var (hour, minute) = emailService.GetScheduledTime();

                    // Converte os valores para uma express�o CRON
                    string cronExpression = $"{minute} {hour} * * *";

                    RecurringJob.AddOrUpdate(
                        "envio-email-diario",
                        () => emailService.ProcessReportAndSendEmail(),
                        cronExpression,
                        new RecurringJobOptions
                        {
                            TimeZone = TimeZoneInfo.Local
                        });
                }

                app.Run("http://localhost:5000");
            }
            catch (Exception ex)
            {
                Log.Fatal(ex, "A aplica��o encerrou inesperadamente.");
            }
            finally
            {
                Log.CloseAndFlush();
            }
        }
    }
}
